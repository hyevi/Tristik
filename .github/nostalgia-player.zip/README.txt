Nostalgia Player: Capacitor project.

1. Create a GitHub repo and upload the contents of this folder (keep the .github folder).
2. Push to main. Open the Actions tab, wait for "Build APK" to finish.
3. Download the nostalgia-player-debug-apk artifact, unzip, install app-debug.apk on your phone.
